package com.example.ElectronicStore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ElectronicStore.daos.CustomerDao;
import com.example.ElectronicStore.entities.Customer;

@Service
public class UserServices {
	
	@Autowired
	private CustomerDao customerDao;
	
	
	public Customer findByEmail(String email) {
		Customer customer = new Customer();
		customer = customerDao.findByEmail(email);
		if (customer != null)
			return customer;
		else
			return null;
	}
	
	public List<Customer> findAll()
	{
		List<Customer> list = customerDao.findAll();
		return list;
	}
	

}
