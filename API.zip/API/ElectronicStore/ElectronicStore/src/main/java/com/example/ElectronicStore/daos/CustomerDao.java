package com.example.ElectronicStore.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ElectronicStore.entities.Customer;

public interface CustomerDao extends JpaRepository<Customer , Integer> 
{
	Customer findByEmail(String email);


}
