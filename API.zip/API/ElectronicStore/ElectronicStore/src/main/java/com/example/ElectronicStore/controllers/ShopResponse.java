package com.example.ElectronicStore.controllers;

public class ShopResponse {
	
	static enum Status{
		success,error
	}
	
	private Status status;
	private Object data;
	private String error;
	
	
	public ShopResponse() {
		super();
	}


	public ShopResponse(Status status, Object data, String error) {
		super();
		this.status = status;
		this.data = data;
		this.error = error;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	public Object getData() {
		return data;
	}


	public void setData(Object data) {
		this.data = data;
	}


	public String getError() {
		return error;
	}


	public void setError(String error) {
		this.error = error;
	}
	
	public static ShopResponse success(Object data) {
		ShopResponse res = new ShopResponse(Status.success, data, null);
		return res;
	}
	
	public static ShopResponse error(String error) {
		ShopResponse res = new ShopResponse(Status.error, null, error);
		return res;
	}
	
	
	

}
