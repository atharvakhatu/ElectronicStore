package com.example.ElectronicStore.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.ElectronicStore.daos.CustomerDao;
import com.example.ElectronicStore.entities.Customer;
import com.example.ElectronicStore.services.UserServices;

@RestController
public class UserController {
	
	@Autowired 
	 private UserServices userServices;
	
	@Autowired
	 private CustomerDao customerDao;
	
	@PostMapping(value = "/user")
	public ShopResponse validateUser(@RequestBody Customer cred)
	{
		System.out.println(cred);
		
		Customer customer = userServices.findByEmail(cred.getEmail());
		System.out.println(customer.toString());
		if(customer != null && customer.getPassword().equals(cred.getPassword())) {
			return ShopResponse.success(customer);
		}
		return ShopResponse.error("Invalid Email or Password");
		
	}
	

}
