(26,'FB 6 Kg 5 Star Front Load Washing Machine 2X Power Dual Steam','Fully-automatic Front load washing machine: Best Wash Quality, Energy and Water efficient
Capacity 6 kg: Suitable for small families / singles & couples
Energy Rating 5 Star: Best in class efficiency
TRISHIELD PROTECTION : IFB washers come with India’s best warranty 4 Years Comprehensive Warranty + 10 years Motor Warranty + 10 years Spares Support
800 RPM: higher spin speeds helps in faster drying',14799.10,'WashingMachine1.jpg'),

(27,'LG 6.5 Kg 5 Star Smart Inverter Fully-Automatic Top Loading Washing Machine','Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use
5 Star Energy Rated Model : Best in class efficiency
Capacity 6.5 Kg : Suitable for bachelors & couples
Manufacturer Warranty: 2 years on product and 10 years on motor*T&C
700 RPM: Higher spin speeds helps in faster drying',14999.00,'WashingMachine2.jpg'),

(28,'Panasonic 6 Kg 5 Star Fully-Automatic Top Loading Washing Machine','Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use
Capacity 6 Kg: Suitable for bachelors & couples ; 680 RPM: Higher the Spin speed,lower the drying time.
Manufacturer Warranty: 2 years on product, 10 years on motor
Customised 8 Wash Programs as per fabric type. Magic Filters in the washer is to effectively trap dirt while washing the clothes,so every loads of cloth come out perfectly dirt-free.
Rustproof Durable Metal Body with stainless steel drum',15999.10,'WashingMachine3.jpg'),

(29,'Samsung 6.5 kg Fully-Automatic Top Loading','Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use
Capacity 6.5 Kg: Suitable for families with 3 to 4 members
Product Warranty: 2 years comprehensive warranty on product and 2 years on motor
RPM 680 : Higher spin speeds helps in faster drying
6 Wash Programs : Normal, Quick wash, Delicates, Soak + Normal, Energy Saving, Eco Tub Clean
Special Features - Stylish design, Intuitive LED control panel, Centre Jet Technology for powerful washing, Monsoon mode for Indian specific use, Air turbo, Auto restart,
 Water level selector, Child lock safety, Power Filtration with magic lint filter, Tempered glass window, Diamond Drum for gentle fabric care',16799.10,'WashingMachine4.jpg'),

(30,'Whirlpool 6.5 Kg 5 Star Royal Fully-Automatic','Fully-automatic top-loading washing machine; 6.5 kg capacity
12 wash programs
Warranty: 2 years on product, 5 years on motor
6th sense smart sensors-smart sensors in the machine automatically sense and indicate low voltage & Water conditions.Senses the laundry load inside the tub and recommends detergent dosage Transparent
Zero pressure fill technology - Whirlpool presents ZPF technology which ensures that the wash tub gets filled 50% faster even if the water pressure is as low as 0.017 MPa',13999.10,'WashingMachine5.jpg'),

(31,'Apple 2021 iPad Mini with A15 Bionic chip','21.08 cm (8.3-inch) Liquid Retina display with True Tone and wide colour
A15 Bionic chip with Neural Engine
Touch ID for secure authentication
12MP Wide back camera, 12MP Ultra Wide front camera with Centre Stage
Available in purple, starlight, pink and space grey
Landscape stereo speakers
Stay connected with ultra-fast Wi-Fi 6',22999.10,'Tablet1.jpg'),

(32,'Lenovo Tab P11 Plus Tablet','11 inch 2K (2000*1200) display| NTSC 70%| Colour Depth 16.7 million| 400 nits brightness| PPI 213; Display Type - 2K, FHD, IPS; Screen Refresh - 60Hz
Calling supported (Yes); 6 GB RAM| 128 GB ROM expandable upto 256 GB; Processor description - Mediatek Helio G90T octa core processor; Operating system - Android 11 OS
Battery power - 7700 mAH battery| 15 hours playback time; charger wattage - 20W, 13 MP Auto-Focus with Flash Rear Camera, 8 MP Fixed Focus Front Camera
Finger print sensor - No, GPS - Yes, Stylus compatible - Yes, Pen Supported; Headphone jack (Yes); Speaker wattage - 4W; Compatibility with external HDD - No, Use Micro SD Card
Quad speakers optimized with Dolby Atmos| Dual Microphone Array| Smart Voice DSP| Face Unlock technology| Dual Tone Metal Body| 7.5 mm thin
1 year warranty; Included Components - Lenovo Tab P11 Plus, 10V/2A charging adapter, USB Type-C charging cable, SIM Pin, Quick Start Guide and Safety Warranty',23999.10,'Tablet2.jpg'),

(33,'realme Pad WiFi+4G Tablet','MediaTek Helio G99 Octa-Core processor | ARM Mali-G57 MC2 GPU | 4GB RAM | 128GB Internal Storage | Expandable upto 1TB with SD Card
2000 x 1200 High Resolution | 90Hz refresh rate| 26.95cm (10.61 inch) 10 Bit Display | 1 Billion Colours | Low Blue Light Eye Protection
Quad Speakers with Dolby Atmos | Long lasting 8000 mAh Battery | Android 12 | MIUI 13 with Android & security updates
8MP Rear Camera with FHD recording | 8MP Front Camera with 105⁰ FOV | Slim Metal Unibody Design',17999.99 ,'Tablet3.jpg'),

(34,'Lenovo M10 Fhd Plus 2Nd Gen','10.3 inch FHD display; 330 nits brightness; Display Type - FHD, IPS, Screen refresh rate - 60 Hz
Calling supported (Yes); 4GB RAM| 128GB ROM| Expandable upto 256 GB; Processor description - MediaTek Helio P22T (8C, 8x A53 @2.3GHz); Operating system - Android 9 Pie
Battery power - 5000 mAH battery; charger wattage - 10W; 8 MP primary camera, 5 MP secondary camera; Camera Flash - No
Finger print sensor - No, GPS - Yes, Stylus compatible - No; Headphone jack (Yes); Speaker wattage - 2W; Compatibility with external HDD - No, Use Micro SD Card
1 year warranty; Included components - Lenovo Tab M10 FHD Plus (2nd Gen), 5V/2A adapter, USB Type-C 2.0, Quick Start Guide, User Guide, Stylus Pen',18999.99 ,'Tablet4.jpg'),

(35,'Xiaomi Pad 5','4 GB RAM | 64 GB ROM | Expandable Upto 1 TB
26.42 cm (10.4 inch) WUXGA+ Display
8 MP Primary Camera | 8 MP Front
Android 11 | Battery: 7100 mAh Lithium Ion
Voice Call (Dual Sim, GSM) | Processor: MediaTek Helio G80', 14999.10,'Tablet5.jpg'),

(36,'boAt Wave Call Smart Watch, Smart Talk','Bluetooth Calling- Wave Call comes with a premium built-in speaker and bluetooth calling via which you can stay connected to your friends, family, and colleagues
Dial Pad- Its dial pad is super responsive and convenient. You can also save upto 10 contacts in this smart watch
Screen Size- Wave Call comes with a 1.69” HD Display that features a bold, bright, and highly responsive 2.5D curved touch interface
Resolution- With 550 nits of brightness get sharper color resolution that brightens your virtual world exponentially.
Design- The ultra slim and lightweight design of the watch is ideal to keep you surfing your wave all day!
Watch Faces- Wave Call comes with 150+ Cloud watchfaces for you to pick from, complementing your every mood and outfit
HR, SpO2 & Breathing- Monitor your heart rate and blood oxygen levels on-the-go with the heart rate and SpO2 monitor. It also comes with Guided Breathing to help you relax and embrace mindfulness.',1299.10,'SmartWatch1.jpg'),

(37,'boAt Wave Call Smart Watch, Smart Talk','Alexa- Alexa built-in Voice Assistant that sets reminders, alarms and answers questions from weather forecasts to live cricket scores at your command!
Screen Size- ;1.69" big square colour LCD display with a round dial features complete capacitive touch experience to let you take control, effortlessly.
Watch Faces- Multiple watch faces with customizable options to match your OOTD, every day!
Brightness- The ambient light display allows automatic adjustment of brightness on the watch, suited to your environment',1700.99,'SmartWatch2.jpg'),

(38,'Fire-Boltt Phoenix Smart Watch','Fire-Boltt is India No 1 Wearable Watch Brand Q122 by IDC Worldwide quarterly wearable device tracker Q122.【Bluetooth Calling Watch】- Fire-Boltt Phoenix enables you to make and 
receive calls directly from your watch via the built-in speaker and microphone. This smartwatch features a dial pad, option to access recent calls & sync your phone’s contacts.;【High Resolution Display】- Comes with a 1.3"
 TFT Color Full Touch Screen and a 240*240 Pixel High Resolution this watch is covered to flaunt the sleek and stylish look always.
【120+ Sports Modes】- Track each activity effectively with this smartwatch & activity tracker. Track your calories, steps and much more while you are on your fitness journey. This fitness tracker has it all;【In Built Mic & Speaker】- 
Get HD calling experience with this power-packed watch. Enhance the look of your wrist with attractive colors and sleek finish',1799.99,'SmartWatch3.jpg'),

(39,'New Fastrack Reflex VOX 2.0 Smart Watch','BT Calling - Enjoy crystal clear calls, hands-free right from your wrist.
HD Display - A massive 1.8” HD display with 450 Nits Brightness for that amazing picture quality.
Music Storage - Store and listen to your playlist on the go.
TWS connect - Connect to audio devices right from the watch and enjoy music.
AI Voice - Connect to Ok Google or Hey Siri just with a tap.
Multisports - Track your sports activities with 50+ multisport modes with simple taps.',4999.99,'SmartWatch4.jpg'),

(40,'Noise Pulse 2 Max Advanced Bluetooth Calling Smart Watch','Massive 1.85" display: See everyday data clearly under the brightest sun on the 1.85'' TFT LCD that sports 550 nits of brightness and the highest screen-to-body ratio.
BT calling: Talk directly to your loved ones from your wrist; manage calls, access your favourite contacts and dial from the dial pad.
Tru Sync: Now connect with the world in a smart way, thanks to Tru Sync technology that ensures faster and stable connection and low power consumption.
Smart DND: Take a break when you want to and get uninterrupted sleep time.
Noise Health Suite: Get started on your fitness journey with a whole range of wellness features in Noise Health Suite and 100 sports modes to support you.
NoiseFit app: Manage your day-to-day life better with the NoiseFit app at your disposal.
150+ cloud-based watch faces: A new day calls for a new face, choose from over 150+ cloud-based watch faces and don a new look every day.',1300.99,'SmartWatch5.jpg'),

(41,'AmazonBasics 5W Bluetooth 5.0 Speaker','The Speaker is easy to carry, fitting neatly in the pocket of your handbag. Its perfect for staying in or going out.
Despite its small size, the speaker delivers crystal-clear audio thanks to its powerful 5W audio driver. Its thin, lightweight design makes it easy to take with you wherever you go.
The speaker boasts a sleek design, with a rubber finish that is both elegant and resilient. Its slim, compact size makes it easy to carry, while the durable construction ensures that it can withstand the rigors of everyday use.
Bluetooth 5.0 is universally compatible with all Bluetooth-enabled devices. Connects easily to all smartphones, laptops, tablets etc.
Battery Life: Extended battery life delivers up to 36 hours of continuous playtime at 70% volume. Charging time: 4hrs 35 mins',799.99,'Speaker1.jpg'),

(42,'ECHO DOT (BLACK) COMBO WITH PHILIPS','Multi-Functional: Set Scenes, Rhythms and Schedules, dim the light and switch between millions of colours with the Wiz App.Material: Polycarbonate
Wifi Requirement: Requires a secured 2.4 GHz Wi-Fi network connection',1399.99,'Speaker2.jpg'),

(43,'Infinity (JBL Fuze Pint, Wireless Ultra Portable Mini Speaker with Mi','Pocket Size Portable Bluetooth Speakers
5 hours Music Playtime Under Optimum Audio Settings and please ensure speaker is 100% charged before usage
Dual Equalizer Modes for Normal & Deep Bass Output
Wireless Bluetooth Streaming
Speakerphone. Frequency Response 180Hz - 20KHz. Signal to noise Ratio 70dB (Aux)
Voice Assistant Integration
Battery Size (mAh) 3.7V/480mAH with Charging Time 2.5 H @ 5V0.5A',700.99,'Speaker3.jpg'),

(44,'PTron Fusion Evo v2 10W','Bluetooth 5.0 Wireless Soundbar; Powerfull 10W Sound Output with BASS; 52mm Dynamic Drivers; 10Hrs Playtime; 10 Meters Wireless Range; Portable Speaker; Multiple Play Modes - BT, 3.5mm Aux,
 TF Card & USB Drive; Built-in Mic for Calls; TWS Function; Integrated Music & Call Controls; Wide Compatibility with; 1200mAh Battery; 
 1 Year Manufacturer Warranty Against Manufacturing Defects Only',1200.00 ,'Speaker4.jpg'),

(45,'Zebronics ZEB-COUNTY 3W','Zeb-county is a compact and handy portable speaker that comes with multi-connectivity options like wireless BT/USB/micro SD and AUX. Wall Mountable Satellite : No
The speaker comes with a call function along with a built-in fm radio too
Speaker impedance 3Ω
Frequency response 120hz-15khz
Charging time 2.5H
Playback time approx. 10 hrs
1 Year warranty-from the date of purchase
To connect to FM: Switch the speaker to FM mode and connect the micro USB cable to the micro USB port of the speaker and leave the other end free (this cable will act as the FM antenna).',1399.99,'Speaker5.jpg'),

(46,'boAt Rockerz 450','playback- It provides a massive battery backup of upto 15 hours for a superior playback time. Charging Time : 3 Hours
Drivers- Its 40mm dynamic drivers help pump out immersive HD audio all day long.
Earcushions- It has been ergonomically designed and structured as an on-ear headphone to provide the best user experience with its comfortable padded earcushions and lightweight design
Controls- You can control your music without hiccups using the easy access controls, communicate seamlessly using the built-in mic, access voice assistant and always stay in the zone
Dual Modes- One can connect to boAt Rockerz 450 via not one but two modes, Bluetooth as well as AUX
1 year warranty from the date of purchase',1499.00,'HeadPhone1.jpg'),

(47,'HP 500 Bluetooth Wireless Over Ear Headphones','Immerse yourself in true sound with HP 500 ultra-portable wireless headphones, equipped with in-built high-sensitivity mic for clear communication even in noisy surroundings
Forget about running out of power with easy and quick USB C charging and a long battery backup of up. to 20 hours
Be free to move and work lag-free with Bluetooth 5.0 connectivity – get 2x the speed and 4x the range.
Designed for prolonged use - enjoy 1-year manufacturer warranty on the device from the date of purchase.',2500.10,'HeadPhone2.jpg'),

(48,'OnePlus Bullets Z2','A quick 10-minute charge delivers up to 20 hours of immersive audio playback
The flagship-level battery life delivers up to 30 hours of non-stop music on a single charge
A large 12.4 mm bass driver delivers uncompromisingly deep bass for powerful beats. Experience incredibly rich audio detail at every frequency with the titanium coating dome',1799.99,'HeadPhone3.jpg'),

(49,'Sony Wh-Ch510 Bluetooth Wireless On Ear Headphones','Comfort : Lightweight, all-day listening with quality sound
Bluetooth : Listen to your favourite tracks wirelessly with a Bluetooth wireless technology by pairing your smartphone or tablet.
Battery Life : With up to 35 hours of battery life, you’ll have enough power for even long trips away.
If your headphones are running low on power, a 10-minute quick charging with the Type-C cable will give you up to 90 minutes of play.
Take music anywhere : Not only are the WH-CH510 headphones compact and lightweight, but the swivel earcups make it easy to safely pack them away in your bag.
Buttons that make listening easy : Use the buttons to play, stop, or skip through tracks and adjust the volume.
Easy hands-free calling : Conversation flows freely with easy hands-free calling, thanks to the built-in microphone. No need to even take your phone from your pocket.',2399.99,'HeadPhone4.jpg'),

(50,'ZEBRONICS Zeb-Thunder Bluetooth Wireless','Comfortable Design: Beat the workday blues with music on Zeb-Thunder wireless headphone that comes in an ergonomic design a perfect fit and design for long hours use. Microphone sensitivity -40dB ±1dB
Soft & comfortable earcups: Listen to music, podcasts and more for long hours with soft ear cups making it super comfortable for daily wear
Adjustable headband: Adust your headband to your comfortable best while you work or listen to music, Charging time 1.5H
9hrs Playback Time: Fall in love with the audio experience with 9 hours of playback time to keep you going. Sensitivity : -113dB ±3dB',2800.00,'HeadPhone5.jpg'),