insert into products values(2,'Haier 195 L 4 Star Direct-Cool Single-Door Refrigerator
','Direct-cool refrigerator which comes with 1 hour Icing Technology to ensures faster ice formation within 60 mins along with super-fast cooling.
Capacity: 195 litres suitable for a medium sized family.
Energy rating: 4 star, Annual energy consumption: 130 kwh/yr
(Please refer energy label on product page or contact brand for more details)
Warranty: 10 Years warranty on Compressor, 1 year warranty on the product
Compressor: The refrigerator comes with reciprocatory Compressor that is ideal for optimum cooling.
The refrigerator comes with PUF insulation that helps retain low temperatures efficiently for better cooling.
Shelf type: Spill proof toughened glass
',15999.10,'fridge2.jpg'),(3,'LG 260L 3 Star Smart Inverter Frost-Free Double Door Refrigerator','The star rating changes are as per BEE guidelines on or before 1st Jan 2023
Frost free refrigerator: Auto defrost function to prevent ice-build up
Capacity 260 L: Suitable for small families and bachelors I freezer capacity: 75L, fresh food capacity: 185L
Energy Rating: 3 Star
Warranty: 1 year on product, 10 years on compressor
Smart inverter compressor ? energy efficient, less noise & more durable
Shelf Type: Trimless tempered Glass - no. of Shelves: 03 - TOP LED: Energy Efficient & Longer Life Span
',32999.10,'fridge3.jpg'),(4,'Samsung 192 L 2 Star Direct Cool Single Door Refrigerator','The star rating changes are as per BEE guidelines on or before 1st Jan 2023
Direct-cool refrigerator : economical and Cooling without fluctuation						
Capacity 192 liters: suitable for families with 2 to 3 members						
Energy Rating: 2 Star						
Manufacturer Warranty: 1 year on product, 10 years on compressor						
Shelf type: spill proof toughened glass						
Inside box: 1 unit Refrigerator & 1 unit user manual with warranty card						
Spl. Features: Stablizer free operation (Voltage range 130V - 290V), Stylish crown design, Big Bottle Guard',45999.99,'fridge3.jpg'),(5,'Whirlpool 200 L 3 Star Inverter Direct-Cool Single Door Refrigerator','Direct-cool refrigerator with UI and horizontal metallic handle: 200 L with 3S Energy rating									
Modern door design with metallic handle, UI for cooling as per your needs and a Steel finish to compliment your house											
Whirlpool 200 L 3 Star Inverter Direct-Cool Single Door Refrigerator									
Direct-cool refrigerator with UI and horizontal metallic handle: 200 L with 3S Energy rating									
Modern door design with metallic handle, UI for cooling as per your needs and a Steel finish to compliment your house											
Whirlpool 200 L 3 Star Inverter Direct-Cool Single Door Refrigerator							
',30666.00,'fridge.jpg'),(6,'Acer Extensa 15','Fast and Easy Computing : Perfect budget laptop under 30000 for students and working professionals that helps get jobs done quickly and efficiently 
thanks to the Intel Pentium Silver N5030 processor.
Redefined Design and Light Weight :The latest Extensa Acer Laptop has been redesigned to be thinner and lighter than ever. With less than 20mm thin 
and with a weight of around 1.9kg, it can accompany you wherever you need to go
Ease of Storage: 4 GB RAM Laptop with 256GB SSD helps easily store and share important projects and data
Enhanced Video Conferencing and Good Battery Life : The Extensa 15 will help improve your all-round video conferencing experience. It maintains a 
strong, consistent wireless signal with the strategically placed Wi-Fi 5 (802.11ac) wireless antenna and MU-MIMO. It also offers battery life upto 6.5 hours.
',24999.03,'fridge6.jpg'),(7,'ASUS VivoBook 15
Processor: Intel Celeron N4020, 1.1 GHz base speed, Up to 2.8 GHz Turbo Speed, 2 cores, 2 Threads, 4MB Cache
Memory & Storage: 4GB SO-DIMM DDR4 2400MHz RAM, Support up to 8GB using 1x SO-DIMM Slot with | Storage: 256GB M.2 NVMe PCIe SSD
Graphics: Integrated Intel HD Graphics
Display: 15.6-inch (39.62 cms), LED-Backlit LCD, HD (1366 x 768) 16:9, 220nits, NanoEdge bezel, Anti-Glare Plane with 45% NTSC, 82% Screen-To-Body Ratio
Operating System: Pre-loaded Windows 11 Home with lifetime validity
Design & battery: Up to 19.9mm Thin | NanoEdge Bezels | Thin and Light Laptop | Laptop weight: 1.8 kg | 37WHrs, 2-cell Li-ion battery | Up to 6 hours battery life 
;Note: Battery life depends on conditions of usage
Keyboard: Chiclet Keyboard with 1.4mm Key Travel
',25999.00,'fridge7.jpg'),(8,'Dell Latitude E5470
','Intel Core i5 6th Gen. - 6200u Processor, 8 GB Ram & 256 GB SSD, 14.1 Inches HD Screen Notebook Computer
Package Content: 1 Dell Latitude E5470 Laptop
Disk Storage: 256 GB SSD
This product is backed by the Amazon Renewed Guarantee',19999.85,'fridge8.jpg'),(9,'HP 15s-Ryzen 3','Processor: AMD Ryzen 3 3250U (2.6 GHz base clock(2h), up to 3.5 GHz max boost clock(2i), 4 MB L3 cache, 2 cores)| Memory & Storage: 8 GB DDR4-2400 SDRAM (1 x 8 GB)|
Storage: 256 GB PCIe NVMe M.2 SSD Precision
Display & Graphics: 39.6 cm (15.6") diagonal, HD, micro-edge, BrightView, 220 nits, 101 ppi,45%NTSC, 1366 x 768 |Graphics: AMD Radeon Graphics; Operating System & 
Pre-installed Software: Pre-loaded Windows 11Home 64 Single Language|Microsoft Office 2021 Home & Student|McAfee LiveSafe (30 days free trial as default)
Ports: 1 SuperSpeed USB Type-C 5Gbps signaling rate, 2 SuperSpeed USB Type-A 5Gbps signaling rate,1 Headphone/microphone Combo,1 AC Smart pin, 1 HDMI 1.4b
Other Features: Webcam: HP True Vision 720p HD Camera with Integrated dual array digital Microphones| Networking: Realtek RTL8821CE 802.11b/g/n/ac (2x2) and
Bluetooth 5 combo MU-MIMO supported, Miracast compatible 
Battery: 3-cell, 41 Wh Li-ion, Support battery fast charge|Audio: Dual Speakers
Software Included: Microsoft Office 365
',28999.01,'fridge9.jpg'),(10,'Lenovo IdeaPad 3 11th Gen','Processor: 11th Gen Intel Core i3-1115G4 | Speed: 3.0 GHz (Base) - 4.1 GHz (Max) | 2 Cores | 4 Threads | 6MB Cache
Display: 15.6 FHD (1920x1080)| TN Technology | 220Nits Brightness | Anti Glare || Memory: 8GB RAM DDR4-2666 | 
Upgradable Up to 12GB || Storage: 512 GB SSD
OS and Software: Windows 11 Home 64 | Office Home and Student 2021 | Xbox GamePass Ultimate 3-month subscription*
Graphics: Integrated Intel UHD Graphics || Design: 1.99 cm Thin and 1.7 kg Light
Battery Life: 45Wh Battery | Upto 7 Hours | Rapid Charge (Up to 80% in 1 Hour) || Ports: 2x USB-A 3.2 Gen 1 | 1x USB-A 2.0 
|1x Headphone / microphone combo jack (3.5mm) | 1x HDMI 1.4 |1x 4-in-1 media reader (MMC, SD, SDHC, SDXC)
Camera (Built in): HD 720p | Fixed Focus | Privacy Shutter | Integrated Dual Array Microphone
Smart Learning Features : Lenovo Aware | Whisper Voice | Eye Care',35999.01,'fridge10.jpg'),(11,'IFB 30 L Convection Microwave Oven','30L Capacity: Suitable for large families.
Convection: Can be used for baking along with grilling, reheating, defrosting and cooking
IFB offer a super warranty 1 year on Microwave Oven & 3 years on magnetron & cavity
IFB Provides starter kit with this product
Control: Touch key pad (membrane) is sensitive to touch and easy to clean
No. of Programs: Weight Defrost, Rotisserie, Grill Mode, Auto Reheat, Delay Start, Keep Warm, 
Express Cooking ,Steam Clean, Disinfect, Deodorize
Child Safety Lock: Ensures complete safety especially for homes with young children
',13999.22,'fridge11.jpg'),(12,'LG 28 L Convection Microwave Oven
','28L Capacity: Suitable for large families
Convection: Can be used for baking along with grilling, reheating, defrosting and cooking; Watts Microwave (Output): 900 ; Microwave Frequency(MHZ): 2450
Warranty: 1 year comprehensive on product
Brand does not provides starter kit with this product.
Touch Key Pad (Membrane) is sensitive to touch and easy to clean
Child Lock: Ensures complete safety especially for homes with small children
Special Features: Quartz Heater, Keep warm, Health Plus Menu, Stainless Steel Cavity (More Hygienic. More Durable), 251 Auto Cook Menu, 
175 Indian Auto Cook Menu, Intellowave Technology
',8999.00,'fridge12.jpg'),(13,'Panasonic 20L Solo Microwave Oven
','20L capacity: Suitable for bachelors & small families; power + innovation 800 watts of high power for fast, Even cooking and delicious results
Re-Heat & Defrost: Auto programmed reheat and defrost modes ensure even heating or defrosting of food without compromising on the textures of flavour.
Auto Cook 51 Menu: Choose from 51 preset recipes ranging from snacks to desserts to make every day meal a gourmet delight.
Vapor Clean: Keep oven odor free and stain free with the touch of a button
Compact design: This countertop microwave with Glass turntable is compact, allowing you to devote less space to electronics and more to interior capacity;
',5999.00,'fridge13.jpg'),(14,'Panasonic 27L Convection Microwave Oven
','27L Capacity: Suitable for families with 3 to 4 members ;Power + Innovation 900 Watts of High Power for Fast, Even Cooking and Delicious Results
360 Degree Heat Wrap: Advanced Heat Wave Ducts ensure even 360 degree distribution of heat for uniform, faster cooking
Auto Cook 101 Menu: Access 101 pre-loaded menus ranging from starters to desserts, to serve up healthy, delicious food every day.
Re-Heat & Defrost: Auto programmed reheat and defrost modes ensure even heating or defrosting of food without compromising on the textures of flavour.
Magic Grill: Dual power of top and back grill work to make food crispier outside and juicy inside. Two Way heating ensures faster cooking.
Vapor Clean: Keep oven odor free and stain free with the touch of a button
Compact Design: This countertop microwave with glass turntable is compact, allowing you to devote less space to electronics and more to interior capacity.
',17999.23,'fridge14.jpg'),(15,'Samsung 28 L Convection Microwave Oven
','28L : Suitable for large families
Convection Microwave Oven: Can be used for baking along with grilling, reheating, defrosting and cooking
1 year standard warranty on Product, 5 years warranty on Magnetron, 10 years warranty on ceramic enamel cavity
Control : Touch Key Pad (Membrane) is sensitive to touch and easy to clean
Programs : Auto Reheat/Cook, Indian Recipe, Dough Proof/Curd, Convection, Grill, Microwave, Power Defrost, Combi (Convection + Grill), Combi (Convection + Microwave), 
Child Lock, Turntable On/Off, Deodorisation, Clock, Eco Mode, 30 sec +
Special Features : Various Cooking Mode, Convection Temperature (40~200 ?), Preheat, Clock, Auto Programs, Auto Cook, Sound on/off, Ceramic Enamel Cavity
',11999.53,'fridge15.jpg'),(16,'OPPO A74 5G
','6.49" Inch 16.5cm FHD+ Punch-hole Display with 2400x1080 pixels. Larger screen to body ratio of 90.5%.Side Fingerprint Sensor
Qualcomm Snapdragon 480 5G GPU 619 at 650 MHz Support 5G sim Powerful 2 GHz Octa-core processor, support LPDDR4X memory and latest UFS 2.1 gear 3 storage
5000 mAh lithium polymer battery
48MP Quad Camera 48MP Main + 2MP Macro + 2MP Depth Lens 8MP Front Camera
Memory, Storage & SIM: 6GB RAM 128GB internal memory expandable up to 256GB Dual SIM nano+nano dual-standby 5G+5G. Color OS 11.1 based on Android v11.0 
operating system Connector type: USB Type C
Display type: LCD
',15999.02,'fridge16.jpg'),(17,'Redmi 9A Sport
','Processor: MediaTek Helio G25 Octa-core; Up to 2.0GHz clock speed
Camera: 13 MP Rear camera with AI portrait| 5 MP front camera
Display: 16.58 centimeters (6.53-inch) HD+ display with 720x1600 pixels and 20:9 aspect ratio
Battery: 5000 mAH large battery with 10W wired charger in-box
Memory, Storage & SIM: 2GB RAM | 32GB storage | Dual SIM (nano+nano) + Dedicated SD card slot
The Selfie camera allows easy and convenient access to your phone with AI face unlock
Form factor:Bar,Operating system:MIUI 12
',6999.00,'fridge17.jpg'),(18,'Redmi 10A
','Camera: 13MP Rear Camera | 5MP Front Camera
Display: HD+(1600x700) IPS LCD display; 15.58 centimeters (6.53 inch); 20:9 aspect ratio
Processor: MediaTek Helio G25 Octa-core processor; Up to 2.0 GHz clock speed
Battery: 5000 mAh large battery with 10W fast charger in-box and Micro USB connectivity
Memory, Storage & SIM:4GB RAM | 64GB storage expandable upto 512GB with dedicated SD card slot | Dual SIM (nano+nano) dual standby(4G+4G)',8999.01,'fridge18.jpg'),(19,'Redmi Note 12
','Display: Super AMOLED (1080x2400) Display with 120Hz Refresh rate; 1200nits peak brightness; 240Hz Touch sampling rate
Processor: Snapdragon 4 Gen1 6nm Octa-core 5G processor for high performance and efficiency with Adreno 619 GPU; Up to 2.0GHz
Camera: 48MP AI Triple camera setup with 8MP Ultra Wide sensor and 2MP Macro camera| 13MP Front camera
Battery: 5000mAh large battery with 33W fast charger in-box and Type-C connectivity
Memory, Storage & SIM: 4GB RAM | 128GB UFS 2.2 storage expandable up to 1TB | Dual SIM (nano+nano) Dual 5G (5G+5G)
',17999.02,'fridge19.jpg'),(20,'Samsung Galaxy S22 5G
','Pro-grade Camera that lets you make your nights epic with Nightography: It?s our brightest innovation yet. The sensor pulls in more light, the Super 
Clear Glass dials down lens flare, and fast-acting AI delivers near-instant intelligent processing.
VisionBooster outshines the sun: Stunning 120Hz Dynamic AMOLED 2X display is crafted specifically for high outdoor visibility, keeping the view clear in bright daylight.
4nm processor, our fastest chip yet: Our fastest, most powerful chip ever. That means, a faster CPU and GPU compared to Galaxy S21 Ultra.
It?s an epic leap for smartphone technology.
Sleek design in a range of colors lets you express yourself how you like. The slim bezels flow into a symmetrical polished frame for an expansive, balanced display.
Corning Gorilla Glass Victus+ on the screen and back panels.
Connector type: usb type c
',52999.00,'fridge20.jpg'),(21,'AmazonBasics 80cms
','Resolution: HDR 10 (1366x768) | Refresh Rate: 60 hertz | 178¿ wide viewing angle
Connectivity: Dual band Wi-Fi (2.4 GHz/ 5 GHz) for easy connectivity and uninterrupted streaming | 2 way Bluetooth 5.0 for wireless connectivity |
3 HDMI ports with ARC support to connect laptops, set top box, Blu-Ray players and gaming consoles | 1 USB port to plug in hard drives and other USB powered devices | 
IR Port to control connected devices like Soundbars and Receivers | Optical audio jack | 3.5mm earphone jack
Sound: 20W Output with Powerful Front-Firing Speakers | Dolby Digital delivers crystal clear audio | Experience cinema like sound with DTS Tru Surround |
Front Firing Speakers radiate sound directly from the front towards you for a more immersive sound experience
Smart TV Features : Fire TV Built-In | Supported Apps: Prime Video | Netflix | Disney+ Hotstar | YouTube | 12000+ apps from Fire OS Store | Voice Remote with Alexa |
DTH Set-Top Box Integration to switch between DTH TV Channels and OTT apps from home screen | Display Mirroring for compatible devices |
Quad core ARM Cortex-A35 CPU @ 2.0GHz | 1.5GB RAM + 8GB Internal Storage
',12999.01,'fridge21.jpg'),(22,'Redmi 164 cm
','Resolution: 4K Ultra HD (3840 x 2160) | Refresh Rate: 60Hz | 178 Degree Viewing angle. Voltage:100-240V?50/60Hz
Connectivity: Dual-band Wi-Fi | Bluetooth 5.0 | 3 HDMI ports to connect latest gaming consoles, set top box, Blu-ray Players |
2 USB ports to connect hard drives and other USB devices | eARC - Dolby Atmos Passthrough eARC HDMI port | Optical Port
Sound: 30 Watts Output | Dolby Audio | DTS Virtual: X | Dolby Atmos pass through eARC | DTS-HD
Smart TV Features : Android TV 10 | PatchWall - Kids Mode with Parental Lock | Smart Curation | Universal search | Language Universe | Indias Top 10 | Okay Google |
Chromecast| Suporting Apps : Netflix, Prime Video, Disney+ Hotstar
',52999.00,'fridge22.jpg'),(23,'Sansui 140 cm','Resolution: 4K Ultra HD (3840x2160) | Refresh Rate: 60 hertz | Wide Viewing Angle
Connectivity: 3 HDMI ports to connect multiple devices | 2 USB ports to connect hard drives and other USB devices | Bluetooth | Wi-Fi | RJ45 | Antenna
Sound: Dolby Audio | DTS | 20 Watts Audio Output
Smart TV Features: Android 10.0, Google Assistant, Alexa Enabled Support, Built-in Chromecast | Performance: CA53 Quad Core Processor | RAM 2GB, ROM 8GB|
Supported Apps: Prime Video, Netflix, Disney + Hotstar, YouTube, Google Play
Display: 4K UHD Android TV | A+ Grade Panel | Wide Colour Gamut | HDR 10 | Crystal Clear Display | High Brightness | Bezel-less Design
',31999.10,'fridge23.jpg'),(24,'Sony Bravia 164 cm
','Resolution: 4K Ultra HD (3840 x 2160) | Refresh Rate: 60 Hertz | 178 Degree wide viewing angle
Connectivity: 3 HDMI ports to connect set top box, Blu Ray players, gaming console | 2 USB ports to connect hard drives and other USB devices
Sound : 20 Watts Output | Open Baffle Speaker| Dolby Audio | Clear Phase
Smart TV Features: Google TV | Watchlist | Voice Search | Google Play | Chromecast | Netflix | Amazon Prime Video | Additional Features: Apple Airplay |
Apple Homekit |Alexa
Display: X1 4K Processor | 4K HDR | Live Colour| 4K X Reality Pro | Motion Flow XR100
',75999.00,'fridge24.jpg'),(25,'TOSHIBA 139 cm
','Resolution : 4K Ultra 
HD (3840x2160) | Refresh Rate : 60 Hertz | ALLM VRR Supported | Bezel-less Design
Connectivity: 3 HDMI ports to connect set top box, Blu Ray players, gaming console (HDMI 1 eARC supported) | 2 USB ports to connect hard drives and other USB devices|
Dual-band Wi-Fi | Bluetooth 5.0
Sound : 24 Watts Output powered by REGZA Power Audio| Dolby Atmos | Dolby Digital for remarkable sound quality
Smart TV features: Google TV with Watchlist | Google Assistant | Chromecast, Miracast, DLNA, Airplay | Auto Low Latency Mode for VRR |
Supported Apps : Netflix, Youtube, Prime Video, Hotstar, SonyLiv, Hungama, JioCinema, Zee5, Eros Now
Display :10 bit A+ Grade Panel | REGZA Engine 4K | Bezel-less Ultra Slim Display Design | Decoding of Dolby Vision, HDR10, HLG | 1 Billion Colours | ALLM for VRR|MEMC
',25999.10,'fridge25.jpg'),(26,'FB 6 Kg 5 Star Front Load Washing Machine 2X Power Dual Steam','Fully-automatic Front load washing machine: Best Wash Quality, Energy and Water efficient
Capacity 6 kg: Suitable for small families / singles & couples
Energy Rating 5 Star: Best in class efficiency
TRISHIELD PROTECTION : IFB washers come with India best warranty 4 Years Comprehensive Warranty + 10 years Motor Warranty + 10 years Spares Support
800 RPM: higher spin speeds helps in faster drying',14799.10,'WashingMachine1.jpg'),

(27,'LG 6.5 Kg 5 Star Smart Inverter Fully-Automatic Top Loading Washing Machine','Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use
5 Star Energy Rated Model : Best in class efficiency
Capacity 6.5 Kg : Suitable for bachelors & couples
Manufacturer Warranty: 2 years on product and 10 years on motor*T&C
700 RPM: Higher spin speeds helps in faster drying',14999.00,'WashingMachine2.jpg'),

(28,'Panasonic 6 Kg 5 Star Fully-Automatic Top Loading Washing Machine','Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use
Capacity 6 Kg: Suitable for bachelors & couples ; 680 RPM: Higher the Spin speed,lower the drying time.
Manufacturer Warranty: 2 years on product, 10 years on motor
Customised 8 Wash Programs as per fabric type. Magic Filters in the washer is to effectively trap dirt while washing the clothes,so every loads of cloth come out perfectly dirt-free.
Rustproof Durable Metal Body with stainless steel drum',15999.10,'WashingMachine3.jpg'),

(29,'Samsung 6.5 kg Fully-Automatic Top Loading','Fully-automatic top load washing machine: Affordable with great wash quality, Easy to use
Capacity 6.5 Kg: Suitable for families with 3 to 4 members
Product Warranty: 2 years comprehensive warranty on product and 2 years on motor
RPM 680 : Higher spin speeds helps in faster drying
6 Wash Programs : Normal, Quick wash, Delicates, Soak + Normal, Energy Saving, Eco Tub Clean
Special Features - Stylish design, Intuitive LED control panel, Centre Jet Technology for powerful washing, Monsoon mode for Indian specific use, Air turbo, Auto restart,
 Water level selector, Child lock safety, Power Filtration with magic lint filter, Tempered glass window, Diamond Drum for gentle fabric care',16799.10,'WashingMachine4.jpg'),

(30,'Whirlpool 6.5 Kg 5 Star Royal Fully-Automatic','Fully-automatic top-loading washing machine; 6.5 kg capacity
12 wash programs
Warranty: 2 years on product, 5 years on motor
6th sense smart sensors-smart sensors in the machine automatically sense and indicate low voltage & Water conditions.Senses the laundry load inside the tub and recommends detergent dosage Transparent
Zero pressure fill technology - Whirlpool presents ZPF technology which ensures that the wash tub gets filled 50% faster even if the water pressure is as low as 0.017 MPa',13999.10,'WashingMachine5.jpg'),

(31,'Apple 2021 iPad Mini with A15 Bionic chip','21.08 cm (8.3-inch) Liquid Retina display with True Tone and wide colour
A15 Bionic chip with Neural Engine
Touch ID for secure authentication
12MP Wide back camera, 12MP Ultra Wide front camera with Centre Stage
Available in purple, starlight, pink and space grey
Landscape stereo speakers
Stay connected with ultra-fast Wi-Fi 6',22999.10,'Tablet1.jpg'),

(32,'Lenovo Tab P11 Plus Tablet','11 inch 2K (2000*1200) display| NTSC 70%| Colour Depth 16.7 million| 400 nits brightness| PPI 213; Display Type - 2K, FHD, IPS; Screen Refresh - 60Hz
Calling supported (Yes); 6 GB RAM| 128 GB ROM expandable upto 256 GB; Processor description - Mediatek Helio G90T octa core processor; Operating system - Android 11 OS
Battery power - 7700 mAH battery| 15 hours playback time; charger wattage - 20W, 13 MP Auto-Focus with Flash Rear Camera, 8 MP Fixed Focus Front Camera
Finger print sensor - No, GPS - Yes, Stylus compatible - Yes, Pen Supported; Headphone jack (Yes); Speaker wattage - 4W; Compatibility with external HDD - No, Use Micro SD Card
Quad speakers optimized with Dolby Atmos| Dual Microphone Array| Smart Voice DSP| Face Unlock technology| Dual Tone Metal Body| 7.5 mm thin
1 year warranty; Included Components - Lenovo Tab P11 Plus, 10V/2A charging adapter, USB Type-C charging cable, SIM Pin, Quick Start Guide and Safety Warranty',23999.10,'Tablet2.jpg'),

(33,'realme Pad WiFi+4G Tablet','MediaTek Helio G99 Octa-Core processor | ARM Mali-G57 MC2 GPU | 4GB RAM | 128GB Internal Storage | Expandable upto 1TB with SD Card
2000 x 1200 High Resolution | 90Hz refresh rate| 26.95cm (10.61 inch) 10 Bit Display | 1 Billion Colours | Low Blue Light Eye Protection
Quad Speakers with Dolby Atmos | Long lasting 8000 mAh Battery | Android 12 | MIUI 13 with Android & security updates
8MP Rear Camera with FHD recording | 8MP Front Camera with 105⁰ FOV | Slim Metal Unibody Design',17999.99 ,'Tablet3.jpg'),

(34,'Lenovo M10 Fhd Plus 2Nd Gen','10.3 inch FHD display; 330 nits brightness; Display Type - FHD, IPS, Screen refresh rate - 60 Hz
Calling supported (Yes); 4GB RAM| 128GB ROM| Expandable upto 256 GB; Processor description - MediaTek Helio P22T (8C, 8x A53 @2.3GHz); Operating system - Android 9 Pie
Battery power - 5000 mAH battery; charger wattage - 10W; 8 MP primary camera, 5 MP secondary camera; Camera Flash - No
Finger print sensor - No, GPS - Yes, Stylus compatible - No; Headphone jack (Yes); Speaker wattage - 2W; Compatibility with external HDD - No, Use Micro SD Card
1 year warranty; Included components - Lenovo Tab M10 FHD Plus (2nd Gen), 5V/2A adapter, USB Type-C 2.0, Quick Start Guide, User Guide, Stylus Pen',18999.99 ,'Tablet4.jpg'),

(35,'Xiaomi Pad 5','4 GB RAM | 64 GB ROM | Expandable Upto 1 TB
26.42 cm (10.4 inch) WUXGA+ Display
8 MP Primary Camera | 8 MP Front
Android 11 | Battery: 7100 mAh Lithium Ion
Voice Call (Dual Sim, GSM) | Processor: MediaTek Helio G80', 14999.10,'Tablet5.jpg'),

(36,'boAt Wave Call Smart Watch, Smart Talk','Bluetooth Calling- Wave Call comes with a premium built-in speaker and bluetooth calling via which you can stay connected to your friends, family, and colleagues
Dial Pad- Its dial pad is super responsive and convenient. You can also save upto 10 contacts in this smart watch
Screen Size- Wave Call comes with a 1.69” HD Display that features a bold, bright, and highly responsive 2.5D curved touch interface
Resolution- With 550 nits of brightness get sharper color resolution that brightens your virtual world exponentially.
Design- The ultra slim and lightweight design of the watch is ideal to keep you surfing your wave all day!
Watch Faces- Wave Call comes with 150+ Cloud watchfaces for you to pick from, complementing your every mood and outfit
HR, SpO2 & Breathing- Monitor your heart rate and blood oxygen levels on-the-go with the heart rate and SpO2 monitor. It also comes with Guided Breathing to help you relax and embrace mindfulness.',1299.10,'SmartWatch1.jpg'),

(37,'boAt Wave Call Smart Watch, Smart Talk','Alexa- Alexa built-in Voice Assistant that sets reminders, alarms and answers questions from weather forecasts to live cricket scores at your command!
Screen Size- ;1.69" big square colour LCD display with a round dial features complete capacitive touch experience to let you take control, effortlessly.
Watch Faces- Multiple watch faces with customizable options to match your OOTD, every day!
Brightness- The ambient light display allows automatic adjustment of brightness on the watch, suited to your environment',1700.99,'SmartWatch2.jpg'),

(38,'Fire-Boltt Phoenix Smart Watch','Fire-Boltt is India No 1 Wearable Watch Brand Q122 by IDC Worldwide quarterly wearable device tracker Q122.【Bluetooth Calling Watch】- Fire-Boltt Phoenix enables you to make and 
receive calls directly from your watch via the built-in speaker and microphone. This smartwatch features a dial pad, option to access recent calls & sync your phone’s contacts.;【High Resolution Display】- Comes with a 1.3"
 TFT Color Full Touch Screen and a 240*240 Pixel High Resolution this watch is covered to flaunt the sleek and stylish look always.
【120+ Sports Modes】- Track each activity effectively with this smartwatch & activity tracker. Track your calories, steps and much more while you are on your fitness journey. This fitness tracker has it all;【In Built Mic & Speaker】- 
Get HD calling experience with this power-packed watch. Enhance the look of your wrist with attractive colors and sleek finish',1799.99,'SmartWatch3.jpg'),

(39,'New Fastrack Reflex VOX 2.0 Smart Watch','BT Calling - Enjoy crystal clear calls, hands-free right from your wrist.
HD Display - A massive 1.8” HD display with 450 Nits Brightness for that amazing picture quality.
Music Storage - Store and listen to your playlist on the go.
TWS connect - Connect to audio devices right from the watch and enjoy music.
AI Voice - Connect to Ok Google or Hey Siri just with a tap.
Multisports - Track your sports activities with 50+ multisport modes with simple taps.',4999.99,'SmartWatch4.jpg'),

(40,'Noise Pulse 2 Max Advanced Bluetooth Calling Smart Watch','Massive 1.85" display: See everyday data clearly under the brightest sun on the 1.85'' TFT LCD that sports 550 nits of brightness and the highest screen-to-body ratio.
BT calling: Talk directly to your loved ones from your wrist; manage calls, access your favourite contacts and dial from the dial pad.
Tru Sync: Now connect with the world in a smart way, thanks to Tru Sync technology that ensures faster and stable connection and low power consumption.
Smart DND: Take a break when you want to and get uninterrupted sleep time.
Noise Health Suite: Get started on your fitness journey with a whole range of wellness features in Noise Health Suite and 100 sports modes to support you.
NoiseFit app: Manage your day-to-day life better with the NoiseFit app at your disposal.
150+ cloud-based watch faces: A new day calls for a new face, choose from over 150+ cloud-based watch faces and don a new look every day.',1300.99,'SmartWatch5.jpg'),

(41,'AmazonBasics 5W Bluetooth 5.0 Speaker','The Speaker is easy to carry, fitting neatly in the pocket of your handbag. Its perfect for staying in or going out.
Despite its small size, the speaker delivers crystal-clear audio thanks to its powerful 5W audio driver. Its thin, lightweight design makes it easy to take with you wherever you go.
The speaker boasts a sleek design, with a rubber finish that is both elegant and resilient. Its slim, compact size makes it easy to carry, while the durable construction ensures that it can withstand the rigors of everyday use.
Bluetooth 5.0 is universally compatible with all Bluetooth-enabled devices. Connects easily to all smartphones, laptops, tablets etc.
Battery Life: Extended battery life delivers up to 36 hours of continuous playtime at 70% volume. Charging time: 4hrs 35 mins',799.99,'Speaker1.jpg'),

(42,'ECHO DOT (BLACK) COMBO WITH PHILIPS','Multi-Functional: Set Scenes, Rhythms and Schedules, dim the light and switch between millions of colours with the Wiz App.Material: Polycarbonate
Wifi Requirement: Requires a secured 2.4 GHz Wi-Fi network connection',1399.99,'Speaker2.jpg'),

(43,'Infinity (JBL Fuze Pint, Wireless Ultra Portable Mini Speaker with Mi','Pocket Size Portable Bluetooth Speakers
5 hours Music Playtime Under Optimum Audio Settings and please ensure speaker is 100% charged before usage
Dual Equalizer Modes for Normal & Deep Bass Output
Wireless Bluetooth Streaming
Speakerphone. Frequency Response 180Hz - 20KHz. Signal to noise Ratio 70dB (Aux)
Voice Assistant Integration
Battery Size (mAh) 3.7V/480mAH with Charging Time 2.5 H @ 5V0.5A',700.99,'Speaker3.jpg'),

(44,'PTron Fusion Evo v2 10W','Bluetooth 5.0 Wireless Soundbar; Powerfull 10W Sound Output with BASS; 52mm Dynamic Drivers; 10Hrs Playtime; 10 Meters Wireless Range; Portable Speaker; Multiple Play Modes - BT, 3.5mm Aux,
 TF Card & USB Drive; Built-in Mic for Calls; TWS Function; Integrated Music & Call Controls; Wide Compatibility with; 1200mAh Battery; 
 1 Year Manufacturer Warranty Against Manufacturing Defects Only',1200.00 ,'Speaker4.jpg'),

(45,'Zebronics ZEB-COUNTY 3W','Zeb-county is a compact and handy portable speaker that comes with multi-connectivity options like wireless BT/USB/micro SD and AUX. Wall Mountable Satellite : No
The speaker comes with a call function along with a built-in fm radio too
Speaker impedance 3Ω
Frequency response 120hz-15khz
Charging time 2.5H
Playback time approx. 10 hrs
1 Year warranty-from the date of purchase
To connect to FM: Switch the speaker to FM mode and connect the micro USB cable to the micro USB port of the speaker and leave the other end free (this cable will act as the FM antenna).',1399.99,'Speaker5.jpg'),

(46,'boAt Rockerz 450','playback- It provides a massive battery backup of upto 15 hours for a superior playback time. Charging Time : 3 Hours
Drivers- Its 40mm dynamic drivers help pump out immersive HD audio all day long.
Earcushions- It has been ergonomically designed and structured as an on-ear headphone to provide the best user experience with its comfortable padded earcushions and lightweight design
Controls- You can control your music without hiccups using the easy access controls, communicate seamlessly using the built-in mic, access voice assistant and always stay in the zone
Dual Modes- One can connect to boAt Rockerz 450 via not one but two modes, Bluetooth as well as AUX
1 year warranty from the date of purchase',1499.00,'HeadPhone1.jpg'),

(47,'HP 500 Bluetooth Wireless Over Ear Headphones','Immerse yourself in true sound with HP 500 ultra-portable wireless headphones, equipped with in-built high-sensitivity mic for clear communication even in noisy surroundings
Forget about running out of power with easy and quick USB C charging and a long battery backup of up. to 20 hours
Be free to move and work lag-free with Bluetooth 5.0 connectivity – get 2x the speed and 4x the range.
Designed for prolonged use - enjoy 1-year manufacturer warranty on the device from the date of purchase.',2500.10,'HeadPhone2.jpg'),

(48,'OnePlus Bullets Z2','A quick 10-minute charge delivers up to 20 hours of immersive audio playback
The flagship-level battery life delivers up to 30 hours of non-stop music on a single charge
A large 12.4 mm bass driver delivers uncompromisingly deep bass for powerful beats. Experience incredibly rich audio detail at every frequency with the titanium coating dome',1799.99,'HeadPhone3.jpg'),

(49,'Sony Wh-Ch510 Bluetooth Wireless On Ear Headphones','Comfort : Lightweight, all-day listening with quality sound
Bluetooth : Listen to your favourite tracks wirelessly with a Bluetooth wireless technology by pairing your smartphone or tablet.
Battery Life : With up to 35 hours of battery life, you’ll have enough power for even long trips away.
If your headphones are running low on power, a 10-minute quick charging with the Type-C cable will give you up to 90 minutes of play.
Take music anywhere : Not only are the WH-CH510 headphones compact and lightweight, but the swivel earcups make it easy to safely pack them away in your bag.
Buttons that make listening easy : Use the buttons to play, stop, or skip through tracks and adjust the volume.
Easy hands-free calling : Conversation flows freely with easy hands-free calling, thanks to the built-in microphone. No need to even take your phone from your pocket.',2399.99,'HeadPhone4.jpg'),

(50,'ZEBRONICS Zeb-Thunder Bluetooth Wireless','Comfortable Design: Beat the workday blues with music on Zeb-Thunder wireless headphone that comes in an ergonomic design a perfect fit and design for long hours use. Microphone sensitivity -40dB ±1dB
Soft & comfortable earcups: Listen to music, podcasts and more for long hours with soft ear cups making it super comfortable for daily wear
Adjustable headband: Adust your headband to your comfortable best while you work or listen to music, Charging time 1.5H
9hrs Playback Time: Fall in love with the audio experience with 9 hours of playback time to keep you going. Sensitivity : -113dB ±3dB',2800.00,'HeadPhone5.jpg')