import Login from "../src/component/login";

function App() {
  return <Login />;
}

export default App;