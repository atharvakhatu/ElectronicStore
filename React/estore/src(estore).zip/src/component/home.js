//import Dashboard from "./dashboard";
import ImageSlider from "./imageslider";


function Home()
{
    return (
    <div >
      <ImageSlider />
    </div>
    
  );
}



export default Home;